#!/bin/bash

TRANSCRIPTS_ROOT=${7:-"/omics/odcf/analysis/OE0606_projects/oncolgy_data_exchange/domenico_temp/xenium/xenium_output_files"}

# Set default directories - can be overridden with command line arguments
SEGGER_DATA_ROOT=${1:-"data_tidy/pyg_datasets/project24_MNG_final"} # path to segger tiles (graphs and embeddings)

MODELS_ROOT=${5:-"./models/project24_MNG_pqdm"}
MODEL_TAG=${2:-"output-XETG00423__0052506__mng_04_TMA__20250310__160549"} # the model that's needed to be used
MODEL_VERSION=${3:-0} # the version of the model


OUTPUT_DIR=${4:-"logs"} # logs dir


OUTPUT_ROOT=${6:-"data_tidy/benchmarks/project24_MNG_final"} # output files


GPU_MEM=${8:-"25.7G"} # fix this based on the compute capacity
SYSTEM_MEM=${9:-"200GB"}

# Create output directory if it doesn't exist
mkdir -p $OUTPUT_DIR

# Get list of samples to process (all except the model tag)
SAMPLES=($(ls $SEGGER_DATA_ROOT | grep -v "$MODEL_TAG"))

# Submit jobs for each sample
for SAMPLE in "${SAMPLES[@]}"; do
    echo "Submitting job for sample: $SAMPLE"
    
    # Create benchmark output directory
    mkdir -p "${OUTPUT_ROOT}/${SAMPLE}"
    
    # Submit with bsub
    bsub -o ${OUTPUT_DIR}/segmentation_${SAMPLE}.log \
         -e ${OUTPUT_DIR}/segmentation_${SAMPLE}.err \
         -gpu "num=1:j_exclusive=yes:gmem=${GPU_MEM}" \
         -R "rusage[mem=${SYSTEM_MEM}]" \
         -q gpu-debian \
         python predict_project24_batch.py \
            --seg_tag "$MODEL_TAG" \
            --sample_id "$SAMPLE" \
            --model_version "$MODEL_VERSION" \
            --gpu_id "0" \
            --models_root "$MODELS_ROOT" \
            --data_root "$SEGGER_DATA_ROOT" \
            --output_root "$OUTPUT_ROOT" \
            --transcripts_root "$TRANSCRIPTS_ROOT" \
            --min_transcripts 5 \
            --score_cut 0.75
done

echo "All jobs submitted"
echo "Configuration:"
echo "  Data root: $SEGGER_DATA_ROOT"
echo "  Model tag: $MODEL_TAG"
echo "  Model version: $MODEL_VERSION"
echo "  Output dir: $OUTPUT_DIR"
echo "  Models root: $MODELS_ROOT"
echo "  Benchmarks root: $BENCHMARKS_ROOT"
echo "  Transcripts root: $TRANSCRIPTS_ROOT"
echo "  GPU memory: $GPU_MEM"
echo "  System memory: $SYSTEM_MEM"